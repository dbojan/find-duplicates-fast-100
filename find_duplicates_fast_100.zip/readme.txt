see https://github.com/dbojan/find-duplicates-fast-100

drop folder with files on bat.

2025-08-03-1