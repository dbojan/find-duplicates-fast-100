from collections import defaultdict
import hashlib
import os
import sys
import time

#2023-08-07-1

#https://stackoverflow.com/questions/748675/finding-duplicate-files-and-removing-them
#base on post by Todor Minakov

print ('Started at:', time.ctime())
start_time = time.time()


list_duplicates = []
list_originals_and_duplicates=[]
list_originals_and_duplicates.append('original'+ '\t' +'size'+ '\t' +'dupicate'+ '\t' +'size')


def chunk_reader(fobj, chunk_size=1024):
	"""Generator that reads a file in chunks of bytes"""
	while True:
		chunk = fobj.read(chunk_size)
		if not chunk:
			return
		yield chunk


def get_hash(filename, first_chunk_only=False, hash=hashlib.sha1):
	hashobj = hash()
	file_object = open(filename, 'rb')

	if first_chunk_only:
		hashobj.update(file_object.read(1024))
	else:
		for chunk in chunk_reader(file_object):
			hashobj.update(chunk)
	hashed = hashobj.digest()

	file_object.close()
	return hashed


def check_for_duplicates(paths, hash=hashlib.sha1):
	hashes_by_size = defaultdict(list)  # dict of size_in_bytes: [full_path_to_file1, full_path_to_file2, ]
	hashes_on_1k = defaultdict(list)  # dict of (hash1k, size_in_bytes): [full_path_to_file1, full_path_to_file2, ]
	hashes_full = {}   # dict of full_file_hash: full_path_to_file_string

	for path in paths:
		for dirpath, dirnames, filenames in os.walk(path):
			# get all files that have the same size - they are the collision candidates
			for filename in filenames:
				full_path = os.path.join(dirpath, filename)
				try:
					# if the target is a symlink (soft one), this will 
					# dereference it - change the value to the actual target file
					full_path = os.path.realpath(full_path)
					file_size = os.path.getsize(full_path)
					hashes_by_size[file_size].append(full_path)
				except (OSError,):
					# not accessible (permissions, etc) - pass on
					continue


	# For all files with the same file size, get their hash on the 1st 1024 bytes only
	for size_in_bytes, files in hashes_by_size.items():
		if len(files) < 2:
			continue	# this file size is unique, no need to spend CPU cycles on it

		for filename in files:
			try:
				small_hash = get_hash(filename, first_chunk_only=True)
				# the key is the hash on the first 1024 bytes plus the size - to
				# avoid collisions on equal hashes in the first part of the file
				# credits to @Futal for the optimization
				hashes_on_1k[(small_hash, size_in_bytes)].append(filename)
			except (OSError,):
				# the file access might've changed till the exec point got here 
				continue

	# For all files with the hash on the 1st 1024 bytes, get their hash on the full file - collisions will be duplicates
	for __, files_list in hashes_on_1k.items():
		if len(files_list) < 2:
			continue	# this hash of fist 1k file bytes is unique, no need to spend cpy cycles on it

		for filename in files_list:
			try: 
				full_hash = get_hash(filename, first_chunk_only=False)
				duplicate = hashes_full.get(full_hash)
				if duplicate:
					#print("Duplicate found: {} and {}".format(filename, duplicate))
					#print("filename:", filename, "duplicate:", duplicate)
					#print("Found duplicate of file:", duplicate, "Duplicate name:", filename)
					list_duplicates.append(filename)
					list_originals_and_duplicates.append(duplicate+ '\t' + str( os.path.getsize(duplicate) )+ '\t' +filename+ '\t' + str( os.path.getsize(filename) )  )
				else:
					hashes_full[full_hash] = filename
			except (OSError,):
				# the file access might've changed till the exec point got here 
				continue


if __name__ == "__main__":
	if sys.argv[1:]:
		print('Checking files for duplicates ...')
		check_for_duplicates(sys.argv[1:])
	else:
		print("Please pass the paths to check as parameters to the script")
		

	
	list_duplicates_delete_bat_file = sys.argv[1] +'-list_duplicates_DELETE.bat'
	if os.path.isfile(list_duplicates_delete_bat_file):
		os.remove(list_duplicates_delete_bat_file)
		
	list_duplicates_txt_file = sys.argv[1] +'-list_duplicates.txt'
	if os.path.isfile(list_duplicates_txt_file):
		os.remove(list_duplicates_txt_file)
		
	list_originals_and_duplicates_txt_file = sys.argv[1] +'-list_originals_and_duplicates.txt'
	if os.path.isfile(list_originals_and_duplicates_txt_file):
		os.remove(list_originals_and_duplicates_txt_file)
	
	if list_duplicates:
		print('Number of duplicates found:', len (list_duplicates))
		list_duplicates.sort()
		counter = 1
		total_size = 0
		lenlist = len(list_duplicates)
		with open(list_duplicates_delete_bat_file, "w") as f:
			f.write('@echo off\n')
			f.write('chcp 65001>Nul\n')
			f.write('echo Deleting duplicates ...\n')
			for item in list_duplicates:
				f.write('title ' + str(counter) + '/' + str(lenlist) +'\n')
				counter = counter+1
				f.write('if exist ' + '"' + item + '"'   + ' attrib -r -h -s -a ' + '"' +item +'"\n')
				f.write('if exist ' + '"' + item + '"'   + ' del /f ' + '"' + item + '"\n'  )
				f.write('if exist ' + '"' + item + '"'   + ' timeout 1 \n')
				f.write('if exist ' + '"' + item + '"'   + ' timeout 1 \n')		
				f.write('if exist ' + '"' + item + '"'   + ' echo error ' + '"' + item + '"'  + 'still exists! Try running this script again.\n')
				if not os.path.islink(item):
					total_size += os.path.getsize(item)
			f.write('echo Done.\n')
			f.write('pause\n')	
		print('Total duplicates size in bytes:', total_size, ' kilobytes:' , total_size//1024, ' megabytes: ', total_size//1024//1024, ' gigabytes:', total_size//1024//1024//1024)

		print('Created file which will DELETE duplicates:', list_duplicates_delete_bat_file)

		print("Saving duplicates list to a file:", list_duplicates_txt_file)
		with open(list_duplicates_txt_file, "w") as f:
			f.write("\n".join(list_duplicates))

		print("Saving originals and duplicates list to a file:", list_originals_and_duplicates_txt_file)
		with open(list_originals_and_duplicates_txt_file, "w") as f:
			f.write("\n".join(list_originals_and_duplicates))

	else:
		print('Number of duplicates found:', len (list_duplicates))#two times, cause I want to print it out after saving duplicates to files text
	
	print('Done.')
	print("--- %.2f seconds ---" % (time.time() - start_time))
	print ('Finished at:', time.ctime())